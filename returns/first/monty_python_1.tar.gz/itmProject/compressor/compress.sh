#java -classpath cclass mycompress $1
#bin/compress $1
python compressor/compress.py $1 $2

